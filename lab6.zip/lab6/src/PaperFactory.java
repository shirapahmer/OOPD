 

public class PaperFactory {
    public static Paper createPaper(String code){
        //TODO: fix
        throw new RuntimeException("wrong PaperType");
    }
}
