public class calcAreaVisitor implements ElementsVisitor{
}
