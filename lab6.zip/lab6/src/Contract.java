
public class Contract implements Paper {
    @Override
    public String write() {
        return "Contract";
    }
}
