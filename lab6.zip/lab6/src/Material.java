 
public enum Material {
    Timber,Metal
}
