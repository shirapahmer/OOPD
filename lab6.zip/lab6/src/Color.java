 
public enum Color {
    Black,
    Red,
    Pink,
    Brown,
    LightBrown,
    Blond
}
