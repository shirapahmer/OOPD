 
//TODO: add decorators (do not change the supplied Paper subclasses)
public interface Paper {
    String write();
}
