 

public class Book implements Paper{
    @Override
    public String write() {
        return "Book";
    }
}
