 

public class AcademicPaper implements Paper{
    @Override
    public String write() {
        return "Academic Paper";
    }
}
