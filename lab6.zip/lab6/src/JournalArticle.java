 

public class JournalArticle implements Paper{
    @Override
    public String write() {
        return "JournalArticle";
    }
}
