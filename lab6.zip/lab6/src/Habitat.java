 
public enum Habitat {
    TERRESTRIAL,
    AQUATIC,
    AMPHIBIAN
}
