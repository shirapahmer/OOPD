public interface Clusterable <T>{
	public double distance(T other);
}
