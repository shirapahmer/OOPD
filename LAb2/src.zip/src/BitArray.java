import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class BitArray implements Clusterable<BitArray>{
	private ArrayList<Boolean> bits;

	public BitArray(String str){
		String[] split_list = str.split(",");
		this.bits = (ArrayList<Boolean>) Arrays.stream(split_list)
				.map(Boolean::valueOf).collect(Collectors.toList());

	}
	public BitArray(boolean[] bits) {
		//dont know how to get the correct stream open and convert the booleans to Booleans
		List.stream(bits).map(Boolean::valueOf).collect(Collectors.toList());
	}

	@Override
	public double distance(BitArray other) {
		return IntStream.range(0, other.bits.size())
				.filter((i) ->other.bits.get(i).equals(bits.get(i))).count();
	}

	public static Set<BitArray> readClusterableSet(String path) throws IOException {

		return Files.lines(Paths.get(path))
				.map(BitArray::new).collect(Collectors.toSet());
	}

	@Override
	public String toString() {
		return bits.toString();
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		BitArray bitArray = (BitArray) o;
		return bits.equals(bitArray.bits);
	}

	@Override
	public int hashCode() {
		return Objects.hash(bits);
	}
}
